﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Doan.Models.Common
{
    public static class CommonConstants
    {
        public const string USER_SESSION = "USER_SESSION";
    }
}