﻿<script>
    $(document).ready(function() {
        $('#dataTables-example').DataTable({
            responsive: true
        })});
    </script>